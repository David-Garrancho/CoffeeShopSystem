package za.ac.cput.interfaces;
/* BundleRepositoryTest.java
 Entity for the BundleRepositoryTest
 Author: Reece Bergstedt - 221075240
 Date: 22 March 2023
*/
import static org.junit.jupiter.api.Assertions.*;
public class BundleRepositoryTest {

    @org.junit.jupiter.api.Test
    void getRepository() {
    }

    @org.junit.jupiter.api.Test
    void create() {
    }

    @org.junit.jupiter.api.Test
    void read() {
    }

    @org.junit.jupiter.api.Test
    void update() {
    }

    @org.junit.jupiter.api.Test
    void delete() {
    }

    @org.junit.jupiter.api.Test
    void getAll() {
    }
}